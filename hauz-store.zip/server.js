require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const nodemailer = require("nodemailer");
const crypto = require("crypto");
const path = require("path");

const app = express();
const db = new Database("hauz-store.sqlite");
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'member',
 points INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS keys_inventory (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 key_value TEXT NOT NULL UNIQUE,
 key_name TEXT NOT NULL,
 game_name TEXT NOT NULL DEFAULT 'All games',
 duration_seconds INTEGER NOT NULL,
 expires_at TEXT,
 status TEXT NOT NULL DEFAULT 'available',
 assigned_user_id INTEGER,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(assigned_user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS free_links (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 url TEXT NOT NULL,
 provider_code TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'stock',
 expires_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS active_free_links (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 free_link_id INTEGER NOT NULL UNIQUE,
 active INTEGER NOT NULL DEFAULT 1,
 sent_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(free_link_id) REFERENCES free_links(id)
);
CREATE TABLE IF NOT EXISTS claims (
 id TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL,
 free_link_id INTEGER NOT NULL,
 provider_verified INTEGER NOT NULL DEFAULT 0,
 code_verified INTEGER NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 completed_at TEXT,
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(free_link_id) REFERENCES free_links(id)
);
CREATE TABLE IF NOT EXISTS key_claims (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 key_id INTEGER NOT NULL UNIQUE,
 claim_id TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(key_id) REFERENCES keys_inventory(id)
);
CREATE TABLE IF NOT EXISTS reset_tokens (
 token_hash TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL,
 expires_at INTEGER NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS giftcodes (
 code TEXT PRIMARY KEY,
 points INTEGER NOT NULL,
 max_uses INTEGER NOT NULL DEFAULT 1,
 uses INTEGER NOT NULL DEFAULT 0,
 expires_at TEXT,
 active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS giftcode_uses (
 user_id INTEGER NOT NULL,
 code TEXT NOT NULL,
 used_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id, code)
);
CREATE TABLE IF NOT EXISTS checkins (
 user_id INTEGER NOT NULL,
 day TEXT NOT NULL,
 points INTEGER NOT NULL,
 PRIMARY KEY(user_id, day)
);
CREATE TABLE IF NOT EXISTS logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 actor_id INTEGER,
 action TEXT NOT NULL,
 detail TEXT,
 ip TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const log = (actor, action, detail, req) => db.prepare(
 "INSERT INTO logs(actor_id,action,detail,ip) VALUES(?,?,?,?)"
).run(actor || null, action, detail || "", req?.ip || "");

const adminName = process.env.ADMIN_USERNAME || "Haune";
if (process.env.ADMIN_INITIAL_PASSWORD) {
  const found = db.prepare("SELECT id FROM users WHERE username=?").get(adminName);
  if (!found) {
    const hash = bcrypt.hashSync(process.env.ADMIN_INITIAL_PASSWORD, 12);
    db.prepare("INSERT INTO users(username,email,password_hash,role) VALUES(?,?,?,'admin')")
      .run(adminName, "admin@hauz-store.local", hash);
    console.log(`Admin ${adminName} created. Change its email in the database before production.`);
  }
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: "." }),
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

const authLimit = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
const requireAuth = (req,res,next) => req.session.user ? next() : res.status(401).json({error:"Vui lòng đăng nhập."});
const requireAdmin = (req,res,next) => req.session.user?.role === "admin" ? next() : res.status(403).json({error:"Chỉ Admin được sử dụng."});
const clean = s => String(s || "").trim();
const safeUser = u => ({id:u.id, username:u.username, email:u.email, role:u.role, points:u.points});

app.post("/api/register", authLimit, async (req,res) => {
  const username = clean(req.body.username), email = clean(req.body.email).toLowerCase(), password = String(req.body.password || "");
  if (!/^[\p{L}\p{N}_-]{3,24}$/u.test(username) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 10)
    return res.status(400).json({error:"Tên tài khoản 3-24 ký tự, email hợp lệ, mật khẩu tối thiểu 10 ký tự."});
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users(username,email,password_hash) VALUES(?,?,?)").run(username,email,hash);
    const user = db.prepare("SELECT * FROM users WHERE id=?").get(result.lastInsertRowid);
    req.session.user = safeUser(user); log(user.id,"register","Tạo tài khoản",req);
    res.json({user:safeUser(user)});
  } catch { res.status(409).json({error:"Tên tài khoản hoặc email đã được sử dụng."}); }
});

app.post("/api/login", authLimit, async (req,res) => {
  const identity = clean(req.body.identity), password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE username=? OR email=?").get(identity, identity.toLowerCase());
  if (!user || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({error:"Thông tin đăng nhập không chính xác."});
  req.session.regenerate(err => {
    if (err) return res.status(500).json({error:"Không thể tạo phiên đăng nhập."});
    req.session.user = safeUser(user); log(user.id,"login","Đăng nhập thành công",req);
    res.json({user:safeUser(user)});
  });
});
app.post("/api/logout", requireAuth, (req,res) => {
  log(req.session.user.id,"logout","Đăng xuất",req);
  req.session.destroy(() => res.json({ok:true}));
});
app.get("/api/me", requireAuth, (req,res) => {
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(req.session.user.id);
  res.json({user:safeUser(u)});
});

app.post("/api/password/forgot", authLimit, async (req,res) => {
  const email = clean(req.body.email).toLowerCase();
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  // Always return the same response to avoid revealing registered emails.
  if (user && process.env.SMTP_HOST && process.env.SMTP_USER) {
    const token = crypto.randomBytes(32).toString("hex");
    const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
    db.prepare("INSERT INTO reset_tokens(token_hash,user_id,expires_at) VALUES(?,?,?)")
      .run(tokenHash,user.id,Date.now()+30*60*1000);
    const transporter = nodemailer.createTransport({
      host:process.env.SMTP_HOST, port:Number(process.env.SMTP_PORT||587),
      secure:process.env.SMTP_SECURE==="true",
      auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}
    });
    const link = `${process.env.BASE_URL || "http://localhost:3000"}/reset.html?token=${token}`;
    await transporter.sendMail({from:process.env.SMTP_FROM,to:user.email,subject:"Đặt lại mật khẩu Hauz Store",text:`Mở liên kết sau trong 30 phút để đặt lại mật khẩu: ${link}`});
  }
  res.json({message:"Nếu email tồn tại và email server đã cấu hình, hướng dẫn đặt lại mật khẩu sẽ được gửi."});
});
app.post("/api/password/reset", authLimit, async (req,res) => {
  const token=clean(req.body.token), password=String(req.body.password||"");
  if (password.length<10) return res.status(400).json({error:"Mật khẩu mới tối thiểu 10 ký tự."});
  const hashToken=crypto.createHash("sha256").update(token).digest("hex");
  const row=db.prepare("SELECT * FROM reset_tokens WHERE token_hash=? AND expires_at>?").get(hashToken,Date.now());
  if (!row) return res.status(400).json({error:"Liên kết không hợp lệ hoặc đã hết hạn."});
  const hash=await bcrypt.hash(password,12);
  db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(hash,row.user_id);
  db.prepare("DELETE FROM reset_tokens WHERE user_id=?").run(row.user_id);
  log(row.user_id,"password_reset","Đặt lại mật khẩu",req);
  res.json({ok:true});
});

// Member: public game catalog, own keys, free-key task and rewards.
app.get("/api/games", requireAuth, (req,res) => res.json({games:[
 "Đoán số bí mật","Đoán chữ","Đố vui IQ","Giải mã mật thư","Sudoku","Nonogram","2048","Minesweeper","Snake","Pong",
 "Breakout","Dino Runner","Space Shooter","Color Switch","Stack Tower","Cờ caro","Cờ vua","Cờ tướng","Connect Four",
 "Battleship","Tower Defense","Xây thành phố","Quản lý nông trại","Memory Cards","Uno mini","Bingo","Xúc xắc",
 "Dungeon Quest","Pixel RPG","Fantasy Adventure","Treasure Hunter","Ninja Adventure","Monster Battle","Bóng đá mini",
 "Bóng rổ mini","Tennis mini","Bowling","Golf mini","Bi-a","Đua xe 2D"
] }));
app.get("/api/my-keys", requireAuth, (req,res) => {
 const rows=db.prepare("SELECT key_name,game_name,key_value,expires_at,status,created_at FROM keys_inventory WHERE assigned_user_id=? ORDER BY id DESC").all(req.session.user.id);
 res.json({keys:rows});
});
app.get("/api/free/status", requireAuth, (req,res) => {
 const links=db.prepare(`SELECT COUNT(*) n FROM active_free_links a JOIN free_links f ON f.id=a.free_link_id WHERE a.active=1 AND f.status='active' AND (f.expires_at IS NULL OR f.expires_at>CURRENT_TIMESTAMP)`).get().n;
 const keys=db.prepare("SELECT COUNT(*) n FROM keys_inventory WHERE status='available'").get().n;
 res.json({links,keys,available:links>0 && keys>0});
});
app.post("/api/free/start", requireAuth, (req,res) => {
 const userId=req.session.user.id;
 const existing=db.prepare("SELECT id FROM claims WHERE user_id=? AND status='pending'").get(userId);
 if(existing) return res.status(409).json({error:"Bạn đang có nhiệm vụ chưa hoàn thành."});
 const link=db.prepare(`SELECT f.* FROM active_free_links a JOIN free_links f ON f.id=a.free_link_id
 WHERE a.active=1 AND f.status='active' AND (f.expires_at IS NULL OR f.expires_at>CURRENT_TIMESTAMP)
 ORDER BY RANDOM() LIMIT 1`).get();
 const keyCount=db.prepare("SELECT COUNT(*) n FROM keys_inventory WHERE status='available'").get().n;
 if(!link) { log(userId,"free_no_links","Hết link",req); return res.status(409).json({error:"Đã hết link. Admin đã được cảnh báo."}); }
 if(!keyCount) { log(userId,"free_no_keys","Hết key",req); return res.status(409).json({error:"Đã hết key. Admin đã được cảnh báo."}); }
 const id=crypto.randomUUID();
 db.prepare("INSERT INTO claims(id,user_id,free_link_id) VALUES(?,?,?)").run(id,userId,link.id);
 log(userId,"free_task_started",`Nhiệm vụ ${id}`,req);
 res.json({claimId:id,title:link.title,url:link.url});
});

// Provider integration: server-to-server verification, then user enters provider-issued code.
// Provider response must be JSON {valid:true, claimId:"...", code:"..."}.
// Adapt this endpoint to the selected provider's documented API before production.
app.post("/api/free/verify", requireAuth, async (req,res) => {
 const claimId=clean(req.body.claimId), code=clean(req.body.code);
 const claim=db.prepare(`SELECT c.*,f.provider_code FROM claims c JOIN free_links f ON f.id=c.free_link_id
 WHERE c.id=? AND c.user_id=? AND c.status='pending'`).get(claimId,req.session.user.id);
 if(!claim) return res.status(404).json({error:"Nhiệm vụ không tồn tại hoặc đã được xử lý."});
 if(!process.env.LINK_PROVIDER_VERIFY_URL || !process.env.LINK_PROVIDER_API_TOKEN)
   return res.status(503).json({error:"Admin chưa cấu hình API nhà cung cấp vượt link."});
 try {
   const response=await fetch(process.env.LINK_PROVIDER_VERIFY_URL,{
     method:"POST",headers:{"content-type":"application/json","authorization":`Bearer ${process.env.LINK_PROVIDER_API_TOKEN}`},
     body:JSON.stringify({claimId,code,providerCode:claim.provider_code})
   });
   if(!response.ok) throw new Error("provider unavailable");
   const result=await response.json();
   if(result.valid!==true || result.claimId!==claimId || result.codeValid!==true) {
     log(req.session.user.id,"free_verification_failed","API hoặc mã xác minh sai",req);
     return res.status(400).json({error:"Sai mã hoặc nhà cung cấp chưa xác nhận hoàn thành nhiệm vụ."});
   }
   // Transaction prevents duplicate claims and simultaneous allocation of the same key.
   const giveKey=db.transaction(() => {
     const fresh=db.prepare("SELECT * FROM claims WHERE id=? AND status='pending'").get(claimId);
     if(!fresh) throw new Error("CLAIM_ALREADY_USED");
     const key=db.prepare("SELECT * FROM keys_inventory WHERE status='available' ORDER BY id LIMIT 1").get();
     if(!key) throw new Error("NO_KEYS");
     const user=db.prepare("SELECT id FROM users WHERE id=?").get(req.session.user.id);
     const expiry=key.duration_seconds>0 ? new Date(Date.now()+key.duration_seconds*1000).toISOString() : null;
     db.prepare("UPDATE keys_inventory SET status='assigned',assigned_user_id=?,expires_at=? WHERE id=? AND status='available'")
       .run(user.id,expiry,key.id);
     db.prepare("INSERT INTO key_claims(user_id,key_id,claim_id) VALUES(?,?,?)").run(user.id,key.id,claimId);
     db.prepare("UPDATE claims SET provider_verified=1,code_verified=1,status='completed',completed_at=CURRENT_TIMESTAMP WHERE id=?").run(claimId);
     return key;
   });
   const key=giveKey();
   log(req.session.user.id,"free_key_issued",`Đã cấp key ${key.key_name}`,req);
   res.json({success:true,key:{name:key.key_name,value:key.key_value,game:key.game_name,expiresAt:key.duration_seconds>0?new Date(Date.now()+key.duration_seconds*1000).toISOString():null}});
 } catch(e) {
   if(e.message==="NO_KEYS") return res.status(409).json({error:"Kho key đã hết. Admin đã được cảnh báo."});
   if(e.message==="CLAIM_ALREADY_USED") return res.status(409).json({error:"Nhiệm vụ này đã được sử dụng."});
   res.status(502).json({error:"Không thể xác minh với nhà cung cấp. Vui lòng thử lại sau."});
 }
});

// Member points: daily check-in and giftcode.
app.post("/api/checkin", requireAuth, (req,res) => {
 const day=new Date().toISOString().slice(0,10), uid=req.session.user.id;
 try {
  db.prepare("INSERT INTO checkins(user_id,day,points) VALUES(?,?,10)").run(uid,day);
  db.prepare("UPDATE users SET points=points+10 WHERE id=?").run(uid);
  log(uid,"daily_checkin","+10 điểm",req);
  res.json({ok:true,points:10});
 } catch { res.status(409).json({error:"Bạn đã điểm danh hôm nay."}); }
});
app.post("/api/giftcode/redeem", requireAuth, (req,res) => {
 const code=clean(req.body.code).toUpperCase(), uid=req.session.user.id;
 try {
  const result=db.transaction(() => {
   const gift=db.prepare("SELECT * FROM giftcodes WHERE code=? AND active=1 AND uses<max_uses AND (expires_at IS NULL OR expires_at>CURRENT_TIMESTAMP)").get(code);
   if(!gift) throw new Error("Mã không hợp lệ, đã hết lượt hoặc hết hạn.");
   db.prepare("INSERT INTO giftcode_uses(user_id,code) VALUES(?,?)").run(uid,code);
   db.prepare("UPDATE giftcodes SET uses=uses+1 WHERE code=?").run(code);
   db.prepare("UPDATE users SET points=points+? WHERE id=?").run(gift.points,uid);
   return gift.points;
  })();
  log(uid,"giftcode_redeemed",code,req); res.json({ok:true,points:result});
 } catch(e) { res.status(400).json({error:e.message.includes("UNIQUE")?"Bạn đã sử dụng mã này.":e.message}); }
});

// Admin dashboard and management.
app.get("/api/admin/summary", requireAuth, requireAdmin, (req,res) => {
 res.json({
  users:db.prepare("SELECT COUNT(*) n FROM users WHERE role='member'").get().n,
  keys:db.prepare("SELECT COUNT(*) n FROM keys_inventory WHERE status='available'").get().n,
  issued:db.prepare("SELECT COUNT(*) n FROM key_claims").get().n,
  links:db.prepare("SELECT COUNT(*) n FROM active_free_links WHERE active=1").get().n
 });
});
app.get("/api/admin/users", requireAuth, requireAdmin, (req,res) => {
 res.json({users:db.prepare("SELECT id,username,email,role,points,created_at FROM users ORDER BY id DESC LIMIT 200").all()});
});
app.post("/api/admin/keys", requireAuth, requireAdmin, (req,res) => {
 const name=clean(req.body.keyName), game=clean(req.body.gameName)||"All games";
 const count=Math.min(500,Math.max(1,Number(req.body.count)||1));
 const duration=Math.max(0,Number(req.body.durationSeconds)||0);
 if(!name) return res.status(400).json({error:"Cần đặt tên key."});
 const created=[];
 const tx=db.transaction(() => {
  for(let i=0;i<count;i++){
   const value="HAUZ-"+crypto.randomBytes(12).toString("hex").toUpperCase();
   db.prepare("INSERT INTO keys_inventory(key_value,key_name,game_name,duration_seconds) VALUES(?,?,?,?)").run(value,name,game,duration);
   created.push(value);
  }
 });
 tx(); log(req.session.user.id,"admin_keys_created",`${count} key: ${name}`,req);
 res.json({created});
});
app.get("/api/admin/keys", requireAuth, requireAdmin, (req,res) => {
 res.json({keys:db.prepare("SELECT id,key_name,key_value,game_name,duration_seconds,status,expires_at,created_at FROM keys_inventory ORDER BY id DESC LIMIT 300").all()});
});
app.post("/api/admin/links", requireAuth, requireAdmin, (req,res) => {
 const title=clean(req.body.title), url=clean(req.body.url), providerCode=clean(req.body.providerCode), expiresAt=clean(req.body.expiresAt)||null;
 try {
  const parsed=new URL(url);
  if(!["https:","http:"].includes(parsed.protocol)) throw new Error();
 } catch { return res.status(400).json({error:"URL không hợp lệ."}); }
 if(!title||!providerCode) return res.status(400).json({error:"Cần tên link và mã nhà cung cấp."});
 const result=db.prepare("INSERT INTO free_links(title,url,provider_code,expires_at) VALUES(?,?,?,?)").run(title,url,providerCode,expiresAt);
 log(req.session.user.id,"admin_link_added",title,req);
 res.json({id:result.lastInsertRowid});
});
app.get("/api/admin/links", requireAuth, requireAdmin, (req,res) => {
 res.json({links:db.prepare("SELECT f.*,a.active AS published FROM free_links f LEFT JOIN active_free_links a ON a.free_link_id=f.id ORDER BY f.id DESC").all()});
});
app.post("/api/admin/links/publish", requireAuth, requireAdmin, (req,res) => {
 const ids=Array.isArray(req.body.ids)?req.body.ids.map(Number).filter(Number.isInteger):[];
 if(!ids.length) return res.status(400).json({error:"Chọn ít nhất một link."});
 const publish=db.transaction(() => {
  let n=0;
  for(const id of ids){
   const f=db.prepare("SELECT id FROM free_links WHERE id=? AND status='stock'").get(id);
   if(!f) continue;
   db.prepare("INSERT OR IGNORE INTO active_free_links(free_link_id,active) VALUES(?,1)").run(id);
   db.prepare("UPDATE free_links SET status='active' WHERE id=?").run(id); n++;
  }
  return n;
 });
 const n=publish(); log(req.session.user.id,"admin_links_published",`${n} link`,req);
 res.json({published:n});
});
app.post("/api/admin/links/:id/disable", requireAuth, requireAdmin, (req,res) => {
 db.prepare("UPDATE active_free_links SET active=0 WHERE free_link_id=?").run(Number(req.params.id));
 db.prepare("UPDATE free_links SET status='disabled' WHERE id=?").run(Number(req.params.id));
 log(req.session.user.id,"admin_link_disabled",req.params.id,req); res.json({ok:true});
});
app.post("/api/admin/giftcodes", requireAuth, requireAdmin, (req,res) => {
 const code=clean(req.body.code).toUpperCase(), points=Math.max(1,Number(req.body.points)||1), max=Math.max(1,Number(req.body.maxUses)||1);
 if(!/^[A-Z0-9_-]{4,32}$/.test(code)) return res.status(400).json({error:"Giftcode 4-32 ký tự A-Z, 0-9, _ hoặc -."});
 try { db.prepare("INSERT INTO giftcodes(code,points,max_uses) VALUES(?,?,?)").run(code,points,max); log(req.session.user.id,"admin_giftcode_created",code,req); res.json({ok:true}); }
 catch { res.status(409).json({error:"Giftcode đã tồn tại."}); }
});
app.get("/api/admin/logs", requireAuth, requireAdmin, (req,res) => {
 res.json({logs:db.prepare("SELECT l.*,u.username FROM logs l LEFT JOIN users u ON u.id=l.actor_id ORDER BY l.id DESC LIMIT 200").all()});
});
app.get("/api/health", (req,res) => res.json({ok:true,service:"Hauz Store"}));

app.use((err,req,res,next) => { console.error(err); res.status(500).json({error:"Lỗi máy chủ."}); });
const port=Number(process.env.PORT||3000);
app.listen(port,()=>console.log(`Hauz Store running at http://localhost:${port}`));
