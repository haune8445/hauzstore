# HAUZ STORE

Starter full-stack app: đăng ký/đăng nhập, quên mật khẩu qua SMTP, kho key, kho link Admin, KEY FREE với xác minh hai bước (API provider + mã), điểm danh, giftcode và log.

## Yêu cầu
- Node.js 20+
- npm

## Cài đặt
```bash
npm install
cp .env.example .env
```
Sửa `.env`:
- `SESSION_SECRET`: chuỗi bí mật dài, ngẫu nhiên.
- `ADMIN_INITIAL_PASSWORD`: mật khẩu Admin mạnh, không chia sẻ.
- `SMTP_*`: cấu hình SMTP thật để gửi email đặt lại mật khẩu.
- `LINK_PROVIDER_VERIFY_URL` và `LINK_PROVIDER_API_TOKEN`: API xác minh của nhà cung cấp link.

Chạy:
```bash
npm start
```
Mở `http://localhost:3000`.

Admin mặc định có username `Haune`; mật khẩu là giá trị `ADMIN_INITIAL_PASSWORD` bạn tự đặt lần đầu. Không có mật khẩu mặc định được nhúng trong mã nguồn. Không thể xem mật khẩu thành viên vì chỉ lưu hash Argon2/bcrypt-compatible bcrypt hash; Admin có thể hỗ trợ reset qua email.

## Tích hợp nhà cung cấp vượt link
Endpoint app gửi POST JSON tới `LINK_PROVIDER_VERIFY_URL` với Bearer token:
```json
{"claimId":"...","code":"...","providerCode":"..."}
```
Nhà cung cấp phải trả JSON:
```json
{"valid":true,"claimId":"...","codeValid":true}
```
Bạn phải thay adapter này theo tài liệu API chính thức của nhà cung cấp đang dùng. Không bật tính năng nhận key thật trước khi kiểm thử callback, chữ ký, chống replay và giới hạn tốc độ. Mỗi claim chỉ được cấp tối đa một key nhờ transaction và unique constraint.

## Thời hạn key
Admin chọn thời lượng khi tạo key. Thời hạn bắt đầu tính từ lúc cấp key. `0` là không giới hạn. Nếu muốn key bắt đầu tính ngay khi tạo, sửa logic `expires_at` trong `server.js`.

## Lưu ý trước khi đưa lên Internet
- Bắt buộc HTTPS và `NODE_ENV=production`.
- Đặt `SESSION_SECRET` mạnh.
- Cấu hình email thật và cập nhật email Admin trong database.
- Dùng reverse proxy, backup database, giám sát lỗi và rate limit bổ sung.
- Cấu hình CSRF protection và kiểm thử bảo mật trước production.
- AI tạo game, thanh toán hosting, chạy game bằng container và bảng xếp hạng hiện chưa kết nối dịch vụ thật; cần API/nhà cung cấp riêng.
- Catalog demo hiện có 40 game mẫu; bổ sung nội dung/game thật trong `/api/games`.
